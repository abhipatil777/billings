<?php
$conn = mysqli_connect('localhost', 'root', '',"waterbilling");
	 if (!$conn)
    {
	 die('Could not connect: ' . mysql_error());
	} 
	

